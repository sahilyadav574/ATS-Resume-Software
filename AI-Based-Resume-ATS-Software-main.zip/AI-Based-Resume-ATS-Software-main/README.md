# AI-Based-Resume-Screening-Software
There were 2 more file, which is not uploaded saying too much file.....
1 was .env file which contains GOOGLE API KEYS, you need to find it from yours, everyone will have different keys. 

run the command : streamlit run app.py in the terminal to run this software.
# Steps:
1. Copy the Job Description from any job profile and paste it in the Job Description area.
2. And upload the resume in the resume upload section.
3. I have added three buttons for the resume. They are: (i) Tell me about Resume. (ii) Percentage Match. (iii) Suggestion Based on Resume.

   These buttons give the response very correct defining the resume, Keyword missing and also suggest job link suitable based on resume.

# Screenshot
![Screenshot (131)](https://github.com/abhishek7673/AI-Based-Resume-ATS-Software/assets/98072917/fe6f1c2b-d40a-4b42-9d04-8f506a35f53f)
![Screenshot (130)](https://github.com/abhishek7673/AI-Based-Resume-ATS-Software/assets/98072917/d2bf4d5f-d740-4dfd-83aa-8e00214314f1)
![Screenshot (129)](https://github.com/abhishek7673/AI-Based-Resume-ATS-Software/assets/98072917/bcdadd78-173f-4546-8186-c0605a6e86ce)
![Screenshot (128)](https://github.com/abhishek7673/AI-Based-Resume-ATS-Software/assets/98072917/5582bdb7-e13d-42a9-844e-69c7a8867141)
